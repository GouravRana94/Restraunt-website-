// Accessing DOM Elements
let VegItemCardOneCounterOne = document.getElementById("VegItemCardOneCounterOne");
let VegItemCardTwoCounterTwo = document.getElementById("VegItemCardTwoCounterTwo");
let VegItemCardThreeCounterThree = document.getElementById("VegItemCardThreeCounterThree");
let VegItemCardFourCounterFour = document.getElementById("VegItemCardFourCounterFour");
let VegItemCardFiveCounterFive = document.getElementById("VegItemCardFiveCounterFive");
let ProductQuantity = 0; // Initial quantity

// Function to Add
function Add() {
  ProductQuantity++;
  VegItemCardOneCounterOne.innerText = ProductQuantity;
}

// Function to Remove
function Remove() {
  if (ProductQuantity > 0) { // Prevent quantity from going negative
    ProductQuantity--;
    VegItemCardOneCounterOne.innerText = ProductQuantity;
  }
}


// Function to Add
function AddTwo() {
    ProductQuantity++;
    VegItemCardTwoCounterTwo.innerText = ProductQuantity;
  }
  
  // Function to Remove
  function RemoveTwo() {
    if (ProductQuantity > 0) { // Prevent quantity from going negative
      ProductQuantity--;
      VegItemCardTwoCounterTwo.innerText = ProductQuantity;
    }
  }

  // Function to Add
function AddThree() {
    ProductQuantity++;
    VegItemCardThreeCounterThree.innerText = ProductQuantity;
  }
  
  // Function to Remove
  function RemoveThree() {
    if (ProductQuantity > 0) { // Prevent quantity from going negative
      ProductQuantity--;
      VegItemCardThreeCounterThree.innerText = ProductQuantity;
    }
  }


  // Function to Add
function AddFour() {
    ProductQuantity++;
    VegItemCardFourCounterFour.innerText = ProductQuantity;
  }
  
  // Function to Remove
  function RemoveFour() {
    if (ProductQuantity > 0) { // Prevent quantity from going negative
      ProductQuantity--;
      VegItemCardFourCounterFour.innerText = ProductQuantity;
    }
  }



  // Function to Add
function AddFive() {
    ProductQuantity++;
    VegItemCardFiveCounterFive.innerText = ProductQuantity;
  }
  
  // Function to Remove
  function RemoveFive() {
    if (ProductQuantity > 0) { // Prevent quantity from going negative
      ProductQuantity--;
      VegItemCardFiveCounterFive.innerText = ProductQuantity;
    }
  }